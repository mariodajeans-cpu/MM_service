function mandarWpp(servico) {
  const texto = `🚨 ${servico}! Vi no site. Preciso urgente em Luanda. Podes vir agora?`;
  const url = `https://wa.me/244940858834?text=${encodeURIComponent(texto)}`;
  window.open(url, '_blank');
}

document.getElementById('formOrcamento').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const nome = document.getElementById('nome').value;
  const servico = document.getElementById('servico').value;
  const zona = document.getElementById('zona').value;
  const detalhes = document.getElementById('detalhes').value;
  
  let texto = `🚨 *SOCORRO - PEDIDO DO SITE* %0A%0A`;
  texto += `*Nome:* ${nome}%0A`;
  texto += `*Emergência:* ${servico}%0A`;
  texto += `*Local:* ${zona}%0A`;
  texto += `*Detalhes:* ${detalhes}%0A%0A`;
  texto += `Me liga agora: 940 858 834`;
  
  const url = `https://wa.me/244940858834?text=${texto}`;
  window.open(url, '_blank');
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.animationPlayState = 'running';
    }
  });
});

document.querySelectorAll('.fade-in').forEach((el) => observer.observe(el));